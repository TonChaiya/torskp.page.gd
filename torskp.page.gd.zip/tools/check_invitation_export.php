<?php
declare(strict_types=1);
// Read-only inspection of the real Word export pipeline. No database, login or web access.
// Run in the project root: php tools/check_invitation_export.php
$root = dirname(__DIR__);
$lib = $root . '/core/word_export_lib.php';
$template = $root . '/templates/docx/committee_scope_invitation.docx';
$vendor = $root . '/vendor/autoload.php';
foreach ([$lib, $template, $vendor] as $file) {
    if (!is_file($file)) { fwrite(STDERR, "Missing: {$file}\n"); exit(1); }
}
require $vendor;
require $lib;
$out = $root . '/word-export-diagnostics';
if (!is_dir($out) && !mkdir($out, 0775, true) && !is_dir($out)) { exit("Cannot create diagnostic directory\n"); }
$example = [
    'department' => 'กองสาธารณสุข ศูนย์สาธารณสุขและการแพทย์ตำบลทรายมูล อ.สันกำแพง โทร. ๐๕๓๓๓ ๑๓๖๒',
    'memo_no_suffix' => '๑๒๓',
    'doc_date' => '๑๙ ตุลาคม ๒๕๖๙',
    'subject' => 'แจ้งคำสั่งและเชิญประชุมแต่งตั้งคณะกรรมการร่างขอบเขตและกำหนดราคากลาง เพื่อจัดซื้อยา ที่องค์การเภสัชกรรมมิได้ผลิตจำหน่าย',
    'item_count' => '๑๕', 'fiscal_year' => '๒๕๗๐',
    'principle_no_suffix' => '๑๑๗', 'principle_date' => '๑๘ ตุลาคม ๒๕๖๙',
    'meeting_date' => '๑๙ ตุลาคม ๒๕๖๙', 'meeting_time' => '๐๙.๓๐ น.',
    'location' => 'ห้องประชุมศูนย์สาธารณสุขและการแพทย์ตำบลทรายมูล อำเภอสันกำแพง จังหวัดเชียงใหม่',
    'signer_signature' => '', 'signer_name' => 'นายสมชาย ใจดี',
    'signer_position_1' => 'นักวิชาการสาธารณสุขชำนาญการ',
    'signer_position_2' => '', 'signer_position_3' => '',
];
$processor = new \PhpOffice\PhpWord\TemplateProcessor($template);
$processor->setValues($example);
$before = $out . '/invitation_before_patch.docx';
$after = $out . '/invitation_after_patch.docx';
$processor->saveAs($before);
if (!copy($before, $after)) { exit("Cannot copy diagnostic file\n"); }
wordPatchDocx($after, 'invitation');
function summarizeDocx(string $file): array {
    $z = new ZipArchive();
    if ($z->open($file) !== true) throw new RuntimeException('Invalid DOCX: '.$file);
    $xml = (string) $z->getFromName('word/document.xml');
    $z->close();
    $doc = new DOMDocument(); $doc->loadXML($xml, LIBXML_NONET);
    $xp = new DOMXPath($doc); $xp->registerNamespace('w', 'http://schemas.openxmlformats.org/wordprocessingml/2006/main');
    $ns = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main';
    $result=[];
    foreach ($xp->query('//w:body//w:p') as $p) {
        $txt=''; foreach ($xp->query('.//w:t', $p) as $t) $txt.=$t->textContent;
        $txt=trim($txt); if ($txt==='') continue;
        $ind=$xp->query('./w:pPr/w:ind',$p)->item(0);
        $al=$xp->query('./w:pPr/w:jc',$p)->item(0);
        $sp=$xp->query('./w:pPr/w:spacing',$p)->item(0);
        $result[] = ['text'=>mb_substr($txt,0,55,'UTF-8'),
            'firstLine'=>$ind instanceof DOMElement ? $ind->getAttributeNS($ns,'firstLine') : '',
            'left'=>$ind instanceof DOMElement ? $ind->getAttributeNS($ns,'left') : '',
            'align'=>$al instanceof DOMElement ? $al->getAttributeNS($ns,'val') : '',
            'line'=>$sp instanceof DOMElement ? $sp->getAttributeNS($ns,'line') : '',
        ];
    }
    return $result;
}
$a = summarizeDocx($before); $b = summarizeDocx($after);
$changes=[];
for ($i=0;$i<min(count($a),count($b));$i++) {
    foreach (['firstLine','left','align','line'] as $key) {
        if ($a[$i][$key] !== $b[$i][$key]) $changes[] = ['paragraph'=>$i+1, 'text'=>$a[$i]['text'], 'property'=>$key, 'before'=>$a[$i][$key], 'after'=>$b[$i][$key]];
    }
}
$report = ['source'=>'GitHub-compatible TemplateProcessor + original wordPatchDocx',
 'before'=>$before, 'after'=>$after,
 'paragraph_count_before'=>count($a), 'paragraph_count_after'=>count($b),
 'format_changes'=>$changes];
file_put_contents($out.'/format_report.json',json_encode($report,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT));
echo "Created:\n  {$before}\n  {$after}\n  {$out}/format_report.json\n";
echo 'Layout property changes (not necessarily defects): '.count($changes)."\n";
echo "Open both DOCX files in Word to compare. This script does not update source files or database.\n";
